<?
$PERM["files"]["2"]="D";
$PERM["files"]["11"]="R";
$PERM["files"]["*"]="D";
?>