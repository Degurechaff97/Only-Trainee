<?
$aMenuLinks = Array(

	Array(
		"Как сделать свой компонент?",
		"/examples/my-components/",
		Array(),
		Array(),
		""
	),

	Array(
		"Список новостей",
		"/examples/my-components/news_list.php",
		Array(),
		Array(),
		""
	),

	Array(
		"Новость детально",
		"/examples/my-components/news_detail.php?ID=9",
		Array("/examples/my-components/news_detail.php"),
		Array(),
		""
	),

	Array(
		"Комплексный компонент",
		"/examples/my-components/news_composite.php",
		Array(),
		Array(),
		""
	),

	Array(
		"Комплексный компонент. ЧПУ",
		"/examples/my-components/news/",
		Array(),
		Array(),
		""
	),

);
?>