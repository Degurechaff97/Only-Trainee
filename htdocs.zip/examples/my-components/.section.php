<?
$sSectionName="Мои компоненты";
?>