<?
$aMenuLinks = Array(
	Array(
		"Меню", 
		"/examples/menu/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Контролируемое скачивание", 
		"/examples/download/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Импорт RSS", 
		"/examples/rss/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Настраиваемая регистрация", 
		"/examples/custom-registration/", 
		Array(), 
		Array(), 
		"" 
	),

	Array(
		"Мои компоненты", 
		"/examples/my-components/", 
		Array(), 
		Array(), 
		"" 
	),

	Array(
		"Правила обработки адресов (ЧПУ)", 
		"/examples/sef/", 
		Array(), 
		Array(), 
		"" 
	),
	
	Array(
		"Форма обратной связи", 
		"/examples/feedback/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>