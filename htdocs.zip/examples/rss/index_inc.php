<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?><div class="information-block">
	<div class="information-block-head">Импорт RSS</div>
	<div class="information-block-body">На данной странице приведен пример организации импорта RSS данных с сайта <a href="http://www.1c-bitrix.ru">www.1c-bitrix.ru</a>. 
Для публикации на сайте данных, получаемых в формате RSS, служит визуальный компонент <i>RSS новости (импорт)</i>, находящийся в разделе <i>Контент&ndash;&gt;RSS</i>. 
В настройках этого компонента указываются адрес сайта для импорта, порт, путь к rss файлу, строка запроса. 

</div>
</div>