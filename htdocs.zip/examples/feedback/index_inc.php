<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?><div class="information-block">
	<div class="information-block-head">Форма обратной связи</div>
	<div class="information-block-body">На данной странице приведен пример формы обратной связи. Сообщение введенное пользователем отправляется на E-mail, указанный в настройках компонента. Для формы можно также задать какие поля обязательные и по каким почтовым шаблонам отравлять сообщения. 
</div>
</div>