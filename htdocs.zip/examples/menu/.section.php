<?
$sSectionName="Меню";
?>