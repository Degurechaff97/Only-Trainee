<?
$sSectionName = "Типовые примеры";
$arDirProperties = array(

);
?>