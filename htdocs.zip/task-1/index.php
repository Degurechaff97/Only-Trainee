<?
				define("B_PROLOG_INCLUDED", true);
				define("WIZARD_DEFAULT_SITE_ID", "02");
				define("WIZARD_DEFAULT_TONLY", true);
				define("PRE_LANGUAGE_ID","ru");
				define("PRE_INSTALL_CHARSET","UTF-8");
				include_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/install/wizard/wizard.php");
				?>