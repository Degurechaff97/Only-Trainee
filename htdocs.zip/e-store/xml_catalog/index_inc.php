<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<div class="information-block">
  <div class="information-block-head">Как сделан каталог товаров из 1С:Предприятие</div>

	<div class="information-block-body">Информация о товарах из 1С:Предприятие получена следующим образом:<br />
	1. Выполнена загрузка каталога товаров из 1С:Предприятие в формате CommerceML 2.0;<br /><br />
	2. Совершен импорт полученных данных в тип инфоблока <i>Каталог товаров 1С</i>.<br />
	</div>
</div>