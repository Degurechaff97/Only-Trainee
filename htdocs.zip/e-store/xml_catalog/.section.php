<?
$sSectionName = "Каталог товаров из 1С.Предприятие";
$arDirProperties = array(

);
?>