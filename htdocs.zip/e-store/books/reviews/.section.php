<?
$sSectionName = "Рецензии";
$arDirProperties = array(

);
?>