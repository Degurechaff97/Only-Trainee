<?
$sSectionName = "Каталог книг";
$arDirProperties = array(

);
?>