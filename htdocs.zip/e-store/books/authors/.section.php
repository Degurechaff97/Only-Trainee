<?
$sSectionName = "Авторы";
$arDirProperties = array(

);
?>