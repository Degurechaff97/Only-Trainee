<?
$aMenuLinks = Array(
	Array(
		"Авторы",
		"/e-store/books/authors/",
		Array(),
		Array(),
		""
	),
	Array(
		"Рецензии",
		"/e-store/books/reviews/",
		Array(),
		Array(),
		""
	),

);
?>