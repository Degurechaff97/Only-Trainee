<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>

<div class="information-block"><?$APPLICATION->IncludeComponent(
	"bitrix:voting.current",
	"main_page",
	Array(
		"CHANNEL_SID" => "BOOKS_VOTE",
		"CACHE_TYPE"	=>	"A",
		"CACHE_TIME"	=>	"3600",
	)
);?> </div>

<div class="information-block">
  <div class="information-block-head">Как сделан каталог книг</div>

  <div class="information-block-body">Информация о книгах структурирована следующим образом: создан тип инфоблока <b>Каталог книг</b>. Для этого типа создано три информационных блока:
    <ul>
      <li>Авторы; </li>

      <li>Книги; </li>

      <li>Рецензии. </li>
    </ul>
  <a href="/e-store/">подробнее...</a> </div>
</div>
