<?
$sSectionName = "Интернет-магазин";
$arDirProperties = array(

);
?>