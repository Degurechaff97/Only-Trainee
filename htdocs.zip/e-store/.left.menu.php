<?
$aMenuLinks = Array(
	Array(
		"Каталог книг", 
		"/e-store/books/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Каталог товаров из 1С:Предприятие", 
		"/e-store/xml_catalog/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>