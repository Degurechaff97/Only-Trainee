<?
$aMenuLinks = Array(
	Array(
		"Настройки пользователя", 
		"/personal/profile/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Персональный рабочий стол", 
		"/personal/desktop.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Подписка", 
		"/personal/subscribe/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>