<?
$sSectionName = "Персональный раздел";
$arDirProperties = array(

);
?>