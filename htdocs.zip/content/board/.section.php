<?
$sSectionName = "Доска объявлений";
$arDirProperties = array(
   "description" => ""
);
?>