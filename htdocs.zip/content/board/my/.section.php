<?
$sSectionName = "Мои объявления";
$arDirProperties = array(

);
?>