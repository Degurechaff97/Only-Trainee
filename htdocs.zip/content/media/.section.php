<?
$sSectionName = "Видео и аудио";
$arDirProperties = Array(

);
?>