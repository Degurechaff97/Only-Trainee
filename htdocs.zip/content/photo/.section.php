<?
$sSectionName = "Галерея";
$arDirProperties = array();
?>