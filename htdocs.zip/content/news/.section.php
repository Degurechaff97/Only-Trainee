<?
$sSectionName = "Новости интернет-магазина";
$arDirProperties = array(

);
?>