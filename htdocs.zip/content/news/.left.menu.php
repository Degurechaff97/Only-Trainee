<?
$aMenuLinks = Array(
	Array(
		"Все новости",
		"/content/news/",
		Array(),
		Array(),
		""
	),
);
?>