<?
$sSectionName = "Статьи";
$arDirProperties = array(

);
?>