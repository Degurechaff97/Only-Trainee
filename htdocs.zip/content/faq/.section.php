<?
$sSectionName = "Часто задаваемые вопросы";
$arDirProperties = array(
);
?>