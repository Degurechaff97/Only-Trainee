<?
$aMenuLinks = Array(
	Array(
		"Статьи", 
		"/content/articles/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Новости", 
		"/content/news/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Видео и аудио", 
		"/content/media/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Галерея", 
		"/content/photo/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Галереи пользователей", 
		"/content/gallery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Доска объявлений", 
		"/content/board/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Каталог ресурсов", 
		"/content/links/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Часто задаваемые вопросы", 
		"/content/faq/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>