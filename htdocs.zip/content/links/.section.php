<?
$sSectionName = "Каталог ресурсов";
$arDirProperties = array(

);
?>