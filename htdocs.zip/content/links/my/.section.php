<?
$sSectionName = "Мои сайты";
$arDirProperties = array(

);
?>