<?
$sSectionName = "Контент";
$arDirProperties = array(

);
?>