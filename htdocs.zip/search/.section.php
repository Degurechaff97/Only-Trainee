<?
$sSectionName = "Поиск";
?>