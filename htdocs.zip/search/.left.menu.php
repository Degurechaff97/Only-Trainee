<?
$aMenuLinks = Array(
	Array(
		"Поиск",
		"/search/",
		Array(),
		Array(),
		""
	),
	Array(
		"Карта сайта",
		"/search/map.php",
		Array(),
		Array(),
		""
	)
);
?>