<?
$sSectionName = "Главная";
$arDirProperties = array(
   "description" => "1С-Битрикс: Управление сайтом",
   "keywords" => "1С-Битрикс, CMS, PHP, bitrix, система управления контентом",
   "robots" => "index, follow"
);
?>