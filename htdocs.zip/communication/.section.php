<?
$sSectionName = "Общение";
$arDirProperties = array(

);
?>