<?
$sSectionName = "Опросы";
$arDirProperties = array(

);
?>