<?
$sSectionName = "Блоги";
$arDirProperties = array(

);
?>