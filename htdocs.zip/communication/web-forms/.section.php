<?
$sSectionName = "Веб-формы";
$arDirProperties = array(

);
?>