<?
$aMenuLinks = Array(
	Array(
		"Анкета посетителя сайта", 
		"/communication/web-forms/anketa/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Обратная связь", 
		"/communication/web-forms/feedback/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>