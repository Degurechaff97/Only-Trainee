<?
$sSectionName = "Анкета посетителя сайта";
$arDirProperties = array(

);
?>