<?
$sSectionName = "Форум";
$arDirProperties = array(

);
?>